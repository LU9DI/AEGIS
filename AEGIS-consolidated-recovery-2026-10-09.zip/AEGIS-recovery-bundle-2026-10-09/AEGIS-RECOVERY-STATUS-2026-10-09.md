# AEGIS — relatório de recuperação e persistência

Data: 2026-10-09

## Verificações feitas

- Diretório de trabalho existe: `/mnt/data/aegis-work/AEGIS-research-lab-v0.26.0/`.
- A árvore contém 246 arquivos de projeto, excluindo caches e bytecode.
- `pyproject.toml` declara `version = "0.26.0"`.
- O ZIP `AEGIS-v0.27.4-four-server-fault-detection-research.zip` existe e passa em `unzip -t`.
- Comparação arquivo a arquivo entre a árvore de trabalho e o ZIP v0.27.4: 246 arquivos em cada lado; 0 ausentes, 0 extras e 0 diferenças de conteúdo.
- SHA-256 do ZIP v0.27.4: `0c8e8c8e4ad49c36cea1db3c39c6a2fc53d719b98eb3d361ed5a579af51dc375`.
- ZIP original de entrada existe: `AEGIS-research-lab-v0.26.0-pir-ops.zip`; SHA-256: `fb423c7074c2ba7c98fdf703eca406865dffaa2bb1e796435c89b36e05acba1c`.
- Não foi encontrado diretório `.git` na árvore de trabalho/área local pesquisada.
- GitHub: o repositório público `LU9DI/AEGIS` existe, mas está vazio. A API retorna `404 repository is empty` para conteúdo e `409 Git Repository is empty` para commits. Portanto, não há commits/arquivos remotos confirmados nesse repositório.

## Pacotes de pesquisa encontrados

- `AEGIS-v0.26.0-verifiable-PIR-design.zip`
- `AEGIS-v0.27.0-verifiable-PIR-research.zip`
- `AEGIS-v0.27.0-signed-snapshot-manifests-research.zip`
- `AEGIS-v0.27.1-persistent-checkpoint-research.zip`
- `AEGIS-v0.27.2-pinned-snapshot-rpc-research.zip`
- `AEGIS-v0.27.3-adversarial-PIR-characterization-research.zip`
- `AEGIS-v0.27.4-four-server-fault-detection-research.zip`

## Limitações

Este relatório descreve somente os arquivos acessíveis no ambiente atual. Não recupera material que existia exclusivamente na conversa apagada e não garante permanência indefinida dos arquivos em `/mnt/data`.

Os pacotes v0.27.x são pacotes de pesquisa, não releases oficiais. Comparação entre respostas de réplicas detecta algumas divergências, mas não equivale a uma prova criptográfica de correção PIR.
